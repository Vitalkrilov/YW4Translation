﻿Just drag-n-drop the CPK file on the "extract.bat" to extract it in a folder
or drag-n-drop the extracted folder on the "repack.bat" to repack it back to a cpk file